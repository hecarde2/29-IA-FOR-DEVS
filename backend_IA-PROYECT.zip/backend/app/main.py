"""
Punto de entrada del backend.

Este es el archivo que arranca todo. Aquí se "conectan" las piezas:
  routers (endpoints)  --->  app FastAPI  --->  servidor uvicorn

Cómo se levanta el servidor (desde la carpeta backend/):
    uvicorn app.main:app --reload

Documentación interactiva generada automáticamente:
    http://127.0.0.1:8000/docs      (Swagger UI)
    http://127.0.0.1:8000/redoc     (ReDoc)
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import APP_DESCRIPTION, APP_TITLE, APP_VERSION
from app.routers import analyze

app = FastAPI(
    title=APP_TITLE,
    description=APP_DESCRIPTION,
    version=APP_VERSION,
)

# CORS: permite que un frontend (si en el futuro se agrega uno, en otro
# dominio/puerto, ej. React en localhost:5173) pueda llamar a esta API
# desde el navegador. Como ahora no hay frontend, queda abierto ("*")
# para que cualquier cliente (Postman, script, futura app) pueda probarla.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Aquí se "conecta" el router de análisis a la app principal.
# Todo lo definido en app/routers/analyze.py queda disponible
# bajo el prefijo /api (definido en ese mismo router).
app.include_router(analyze.router)


@app.get("/", tags=["Estado"])
async def root():
    """Endpoint simple para verificar que el backend está vivo."""
    return {
        "status": "ok",
        "servicio": APP_TITLE,
        "docs": "/docs",
    }
