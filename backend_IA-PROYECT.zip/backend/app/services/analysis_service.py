"""
Capa de "servicio": aquí vive la lógica de negocio, separada del router.
Esto permite reutilizar y probar la lógica sin depender de FastAPI,
y es el lugar donde en el futuro se conectaría un traductor real
o un modelo de IA para la extracción de datos.
"""

import tiktoken

from app.core.config import TOKEN_ENCODING
from app.models.schemas import (
    AnalysisResponse,
    ExtractedErrorData,
    SeverityLevel,
    TokenMetrics,
)

# El encoder se carga una sola vez cuando arranca la app (no en cada request)
_encoder = tiktoken.get_encoding(TOKEN_ENCODING)


def _traducir_es_a_en(texto_es: str) -> str:
    """
    Traducción SIMULADA (placeholder).
    En una versión real, aquí se llamaría a un servicio de traducción
    (por ejemplo la API de OpenAI/Anthropic, DeepL, Google Translate, etc.)
    Se deja aislada en su propia función para que sea fácil de reemplazar.
    """
    return (
        "The app crashes unexpectedly every time I try to upload "
        "a profile picture from my phone's gallery."
    )


def _extraer_datos_error(texto_es: str, texto_en: str) -> ExtractedErrorData:
    """
    Extracción SIMULADA de datos estructurados a partir del texto.
    En una versión real, aquí se llamaría a un modelo de IA (LLM)
    con function calling / structured output para clasificar el error.
    """
    return ExtractedErrorData(
        error_type="crash",
        component="profile_picture_upload",
        severity=SeverityLevel.HIGH,
        summary_en="App crashes when uploading profile picture from gallery.",
        summary_es="La app se cierra al subir foto de perfil desde la galería.",
    )


def analizar_resena(texto_es: str) -> AnalysisResponse:
    """
    Orquesta el análisis completo de una reseña:
    1. Traduce (simulado).
    2. Cuenta tokens en ambos idiomas con tiktoken.
    3. Extrae datos estructurados del error (simulado).
    Devuelve el objeto listo para responder al cliente.
    """
    texto_en = _traducir_es_a_en(texto_es)

    count_es = len(_encoder.encode(texto_es))
    count_en = len(_encoder.encode(texto_en))
    tokens_ahorrados = count_es - count_en

    metrics = TokenMetrics(
        original_tokens=count_es,
        translated_tokens=count_en,
        tokens_saved_per_request=tokens_ahorrados,
    )

    extracted_data = _extraer_datos_error(texto_es, texto_en)

    return AnalysisResponse(metrics=metrics, extracted_data=extracted_data)
