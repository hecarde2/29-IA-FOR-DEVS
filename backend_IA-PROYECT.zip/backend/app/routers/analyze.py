"""
Router (controlador) del recurso "analyze".
Un router es un grupo de endpoints relacionados que luego se
"conecta" (include_router) a la app principal en app/main.py.

Aquí NO va lógica de negocio: solo se valida la petición
y se delega el trabajo real al servicio (app/services/analysis_service.py).
"""

from fastapi import APIRouter, HTTPException

from app.models.schemas import AnalysisResponse, ReviewRequest
from app.services.analysis_service import analizar_resena

router = APIRouter(prefix="/api", tags=["Análisis de reseñas"])


@router.post("/analyze", response_model=AnalysisResponse)
async def analyze_review(payload: ReviewRequest) -> AnalysisResponse:
    """
    Recibe una reseña en español y devuelve:
    - Métricas de tokens (ES vs EN, con tiktoken).
    - Datos estructurados extraídos del error reportado.
    """
    texto_es = payload.text.strip()
    if not texto_es:
        raise HTTPException(status_code=400, detail="El texto no puede estar vacío.")

    return analizar_resena(texto_es)
